﻿using GCSideLoading.Core.ViewModel;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Collections.Generic;

namespace GCSideLoading.Web.Models
{
    public class HomePageViewModel : PageModel
    {
        public HomePageViewModel()
        {
        }
    }
}
