﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GCSideLoading.Core
{
    public class GCSideLoadingEmailConfig
    {
        public string UserNameKey { get; set; }
        public string PasswordKey { get; set; }
        public string HostKey { get; set; }
        public string PortKey { get; set; }
        public string SslKey { get; set; }
    }
}
