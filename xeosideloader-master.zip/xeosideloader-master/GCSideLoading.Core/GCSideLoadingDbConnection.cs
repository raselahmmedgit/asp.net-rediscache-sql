﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GCSideLoading.Core
{
    public class GCSideLoadingDbConnection
    {
        public string EndPointUrl { set; get; }
        public string AuthKey { set; get; }
        public string DatabaseId { set; get; }
    }
}
