﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GCSideLoading.Core.SmsSender
{
    public class SmsConfiguration
    {
        public string Number { get; set; }
    }
}
