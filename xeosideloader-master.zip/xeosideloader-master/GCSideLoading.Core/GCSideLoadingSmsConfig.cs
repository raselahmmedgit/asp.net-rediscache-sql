﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GCSideLoading.Core
{
    public class GCSideLoadingSmsConfig
    {
        public string TwilioFromNumber { get; set; }
        public string TwilioAccountSid { get; set; }
        public string TwilioAuthToken { get; set; }
    }
}
